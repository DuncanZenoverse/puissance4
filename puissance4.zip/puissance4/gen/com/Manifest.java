package com.puissance4;

public final class Manifest {
}