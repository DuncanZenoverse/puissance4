package com.puissance4;

public final class BuildConfig {
  public final static boolean DEBUG = Boolean.parseBoolean(null);
}