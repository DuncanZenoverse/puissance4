package com.puissance4.activities;

import android.widget.PopupMenu;
import com.puissance4.models.Player;

public interface GameActivty {
    public void popupWin(Player p);
}
